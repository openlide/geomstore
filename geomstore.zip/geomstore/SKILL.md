---
name: geomstore
description: 微信小程序状态管理库 GeomStore（@openlide/geomstore）的完整使用指南。当需要编写、修改或审查使用 GeomStore 的代码（创建 Store、定义 actions/getters、接入微信小程序 Page/Component/App、使用插件/选择器/Store 组合/错误处理/性能监控/快照/缓存/Action 装饰器等）时使用此 skill。触发场景：开发微信小程序并涉及状态管理、用户要求"用 GeomStore 实现 XX"、代码中已存在 createStore/withPageStore/composeStore 等 API 调用、或需要排查 GeomStore 相关问题。
---

# GeomStore 使用指南

## Overview

GeomStore v1.0 是轻量级微信小程序状态管理库，提供类似 Pinia 的 API 设计、完整的 TypeScript 类型推断、企业级功能（Store 组合、插件系统、错误处理、性能监控、快照系统、Action 增强）以及原生微信小程序集成（支持 Skyline 与 Webview）。本 skill 指导 CodeBuddy 正确使用 GeomStore 的 API 编写、修改与审查代码。

## 使用规则

- **所有 API 使用前先查阅 `references/api.md`** 获取完整签名、示例与注意事项，避免凭记忆写错 API。
- **包引用路径**：npm 包名 `@openlide/geomstore`，子路径模块通过 `@openlide/geomstore/xxx` 导入（如 `@openlide/geomstore/integrations`、`@openlide/geomstore/plugins`）。微信小程序中需先"构建 npm"。
- **状态只能通过 action 修改**：禁止直接赋值 `store.state.xxx = value`（状态保护开启时会抛出/警告，且不会触发订阅通知）。合法修改方式：action 内写 `this.state.xxx`、`this.setState(k, v)`、`this.$patch(partial)`、`this.$replaceState(newState)`。
- **action 的 `this` 上下文**：action 内 `this` 指向 ActionContext，含 `state`、`setState`、`$patch`、`$replaceState`、`getState`、`dispatch`，以及当前 store 的其他 action（可互相调用）。action 参数为调用时传入的用户参数。
- **getter 是纯函数**：`(state) => value`，只读派生状态，不应有副作用。

## 快速上手

### 1. 安装

```bash
npm install @openlide/geomstore
# 微信开发者工具中：工具 -> 构建 npm
```

### 2. 创建 Store

```typescript
// store/counter.ts
import { createStore } from '@openlide/geomstore'

export const counterStore = createStore({
  name: 'counter',
  state: { count: 0, name: 'test' },
  actions: {
    increment() { this.state.count++ },
    add(n: number) { this.state.count += n },
    async fetchData() {
      const res = await request('/api/data')
      this.setState('count', res.data)
    },
  },
  getters: {
    double(state) { return state.count * 2 },
  },
})

// 类型安全调用
counterStore.dispatch('add', 10)          // 参数自动推断为 number
counterStore.getter('double')             // 返回类型自动推断为 number
counterStore.subscribe((state) => { ... })
```

### 3. 接入微信小程序

**Page（页面）**：

```typescript
// pages/counter/index.ts
import { withPageStore } from '@openlide/geomstore/integrations'
import { counterStore } from '../../store/counter'

Page(withPageStore(counterStore, {
  // 数组简写：本地名 = store 名
  mapState: ['count'],
  mapActions: ['increment'],
  // 对象形式支持重命名：{ 本地名: store名 }
  // mapState: { total: 'count' }, mapActions: { addOne: 'increment' },
})({
  data: { localData: '...' },
  onLoad() {
    console.log(this.data.count)   // 从 store 映射
    this.increment()               // 调用 action
  },
}))
```

**Component（组件）**：使用 `withComponentStore`，映射的 action 自动合并进 `methods`，生命周期用 `lifetimes.attached/detached`、`pageLifetimes.show`。

**App（全局）**：使用 `withAppStore` 或 `createApp`，状态同步到 `globalData`，并暴露调试 API：

```typescript
import { withAppStore } from '@openlide/geomstore/integrations'

App(withAppStore(appStore, { mapState: ['userInfo'], mapActions: ['initApp'] })({
  onLaunch() { this.initApp() },
}))
// 其他位置：const app = getApp(); app.getStore(); app.getState(); app.dispatch('xxx')
```

## 常见任务

### 任务一：订阅状态变化

```typescript
const unsubscribe = store.subscribe((state) => {
  console.log('state changed', state)
})
unsubscribe() // 取消订阅
```

批量更新时使用 `store.batch(() => {...})` 合并多次变更的订阅通知。

### 任务二：安装插件

```typescript
store.use(loggerPlugin)                          // 开发日志（生产环境自动禁用）
store.use(persistencePlugin)                     // 持久化（默认 wx 存储）
store.use(persistencePlugin({                    // 自定义持久化
  key: 'app-state',
  filter: (s) => ({ user: s.user }),             // 只持久化部分状态
  validate: (s) => s && typeof s.user === 'object', // 恢复前校验
  debounce: 200,                                 // 防抖
}))
store.use(devtoolsPlugin)                        // 暴露 __GEOMSTORE_STORES__ / __GEOMSTORE_DEVTOOLS__
// 性能监控 / 时间旅行
store.use(analyzerPlugin)                        // globalThis.__GEOMSTORE_ANALYZER__
store.use(timeTravelPlugin({ maxSize: 100 }))    // store.__timeTravel__.undo()
```

### 任务三：使用选择器

```typescript
import { createSelector, createMemoizedSelector, createParametricSelector } from '@openlide/geomstore'

const selectCount = createSelector((s) => s.count)          // 基础
const memoDouble = createMemoizedSelector((s) => s.count * 2) // 记忆化
const selectItem = createParametricSelector((s, id) => s.items[id]) // 按参数取
```

### 任务四：Store 组合（模块化）

```typescript
import { composeStore } from '@openlide/geomstore'

const root = composeStore([userStore, cartStore], {
  namespace: true,   // 命名空间模式：键为 'userStore/xxx'
  strict: true,      // 访问不存在的 store 时报错
})
// root.$patch({ 'userStore/name': 'Alice' })
```

### 任务五：Action 增强（装饰器）

```typescript
import { withRetry, withTimeout } from '@openlide/geomstore'

const store = createStore({
  state: { loading: false },
  actions: {
    // withRetry/withTimeout 返回包装函数，包在 action 外层
    fetchUser: withRetry(async () => { ... }, { retries: 3, delay: 500 }),
    slowTask: withTimeout(() => { ... }, 3000),
  },
})
```

### 任务六：错误处理

```typescript
import { ErrorBoundary, ErrorRecovery, RecoveryStrategy } from '@openlide/geomstore'

const boundary = new ErrorBoundary({ onError: (ctx) => console.error(ctx.error) })
const recovery = new ErrorRecovery()
recovery.configure('E_ACTION_FAILED', RecoveryStrategy.retry(3))
```

### 任务七：快照与性能

```typescript
import { createSnapshot, createSnapshotAsync, PerformanceMonitor, LRUCache } from '@openlide/geomstore'

const snap = createSnapshot(store.state)          // 深克隆
store.$restore(snap)                              // 恢复
const cache = new LRUCache({ capacity: 100, ttl: 60000 })
```

## 性能与最佳实践

- **使用 getter 派生状态**而非在组件中重复计算；使用 `createMemoizedSelector` 缓存计算密集型选择器。
- **大量状态时**可设置 `notify: { clone: false }` 进入零拷贝通知模式（监听器收到只读代理，需自行保证不修改）。
- **多个状态字段一起更新**用 `$patch` 或 `batch()`，避免多次触发订阅通知。
- **缓存热点 state 键**：`createStore({ enableCache: true, cacheKeys: ['count'], cacheConfig: { capacity: 100 } })`，读取用 `store.getCached('count')`。
- **生产环境**自动禁用 logger/devtools 插件输出，无需手动处理。
- **不要在 onHide 中依赖 App 级订阅清理**：`withAppStore` 的订阅贯穿小程序运行期，只在 onLaunch 建立。
- **同页面多实例**（页面栈同名页、列表项组件）的订阅清理由集成层挂在实例上（`__lideUnbinds`），无需手动管理。

## 常见错误排查

| 错误/现象 | 原因与修复 |
| --- | --- |
| `Cannot find module '@openlide/geomstore'` | 未安装依赖或未执行"构建 npm"；确认子路径模块名拼写（如 `@openlide/geomstore/integrations`） |
| 直接改 state 不生效/被警告 | 必须通过 action 修改，用 `dispatch` 或 `store.$patch` |
| `dispatch` 参数类型报错 | 使用类型安全重载，传入匹配 action 签名的参数 |
| 订阅回调不触发 | 检查是否在 `batch()` 内只读未写；检查 `notify.onlyOnChange` 配置（未变更不通知） |
| 持久化恢复失败 | 恢复状态必须是纯对象；`validate` 校验失败会跳过恢复 |
| 时间旅行/analyzer API 不存在 | 需先安装对应插件（`timeTravelPlugin` / `analyzerPlugin`），且非生产环境 |

## Resources

本 skill 的详细 API 参考位于 `references/api.md`，包含：

- 全部导出函数/类的签名、参数与返回值
- 每个模块的完整用法示例与注意事项
- Store 选项、插件选项、组合选项等配置说明
- 类型系统（Store/State/Actions/Getters/ConnectOptions 等）说明

编写代码前应查阅该文件获取准确 API 信息。
