# GeomStore API 参考

> GeomStore v1.0.0 · npm 包名 `@openlide/geomstore` · 源码位于仓库 `src/` 目录
>
> 本文档为 CodeBuddy 使用 GeomStore 时的准确 API 参考，签名与行为均核对源码。

## 导入路径与模块结构

所有模块可从根包 `@openlide/geomstore` 导入，亦支持子路径按需导入（减少包体）。微信小程序需先执行"工具 → 构建 npm"。

| 子路径 | 导出内容 |
| --- | --- |
| `@openlide/geomstore` | 全部核心 API（见下） |
| `@openlide/geomstore/store` | `Store`、`createStore`、`isGeomStore` 及相关类型 |
| `@openlide/geomstore/hooks` | `HookSystem`、`usePlugin`、插件/钩子类型 |
| `@openlide/geomstore/plugins` | 内置插件 + 钩子系统 + `timeTravelPlugin` + `analyzerPlugin` |
| `@openlide/geomstore/plugins/devtools` | `timeTravelPlugin`、`TimeTravelOptions` |
| `@openlide/geomstore/plugins/performance` | `analyzerPlugin`、`createAnalyzerPlugin` |
| `@openlide/geomstore/integrations` | 微信小程序集成：`withPageStore`、`withComponentStore`、`withAppStore`、`createApp`、企业级方案 |
| `@openlide/geomstore/integrations/enterprise` | `createUserStore`、`StoreManager`、`OfflineManager`、`initHotUpdate`、`initBackgroundSync`、`createEnterpriseApp` 等 |
| `@openlide/geomstore/error` | 错误处理全套 |
| `@openlide/geomstore/compose` | `composeStore`、`createStoreTree`、`StoreRegistry`、`globalRegistry` |
| `@openlide/geomstore/selectors` | 选择器全套 |
| `@openlide/geomstore/snapshot` | 快照全套 |
| `@openlide/geomstore/performance` | 性能监控 + 优化工具 |
| `@openlide/geomstore/actions` | Action 增强全套 |
| `@openlide/geomstore/cache` | `LRUCache` |

---

## 一、核心 Store

### `createStore(options): Store`

创建带完整类型推断的 Store 实例。`options` 为 `StoreOptions<S, A, G>`。

```typescript
import { createStore } from '@openlide/geomstore'

const store = createStore({
  name: 'counter',                              // 可选，Store 标识（默认生成）
  state: { count: 0, name: 'test' },            // 初始状态
  actions: {
    increment() { this.state.count++ },         // this 指向 ActionContext
    add(n: number) { this.state.count += n },
  },
  getters: {
    double(state) { return state.count * 2 },
  },
})
```

### `StoreOptions<S, A, G>`

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `name?` | `string` | Store 名称，用于 devtools/命名空间 |
| `state?` | `S` | 初始状态 |
| `actions?` | `ActionsWithThis<S, A>` | action 集合，`this` 注入 ActionContext |
| `getters?` | `G` | 派生状态，`(state) => value` |
| `enableCache?` | `boolean` | 是否启用状态缓存 |
| `cacheKeys?` | `Array<keyof S>` | 需要缓存的 state 键（为空则缓存所有） |
| `cacheConfig?` | `CacheConfig` | `{ capacity?, ttl?, trackAccessTime?, enableStats? }` |
| `stateProtection?` | `StateProtectionOptions` | 状态保护：`{ enabled?, deep?, productionHandler? }`（默认开启，deep 默认 true） |
| `subscription?` | `SubscriptionOptions` | `{ maxSubscribers? (默认50), onLimit? ('evict-oldest'默认/'throw') }` |
| `notify?` | `NotifyOptions` | `{ clone? (通知前深拷贝，默认true), onlyOnChange? (默认false) }` |

### Action 上下文（action 内的 `this`）

```typescript
actions: {
  async login(credentials) {
    this.state                 // 读写状态（推荐）
    this.setState('count', 10) // 设置单个状态
    this.$patch({ a: 1, b: 2 })  // 批量更新
    this.$replaceState(newState) // 整体替换
    this.getState()            // 获取状态副本
    this.dispatch('otherAction', args) // 动态调用其他 action
    await this.someOtherAction()       // 直接调用本 store 其他 action
  }
}
```

### `Store` 实例方法

| 方法 | 签名 | 说明 |
| --- | --- | --- |
| `getState` | `(): S` | 获取状态 |
| `setState` | `<K extends keyof S>(key: K, value: S[K]): void` | 设置单个状态 |
| `$patch` | `(partialState: Partial<S>): void` | 批量更新 |
| `$replaceState` | `(newState: S): void` | 替换整个状态 |
| `$snapshot` | `(): Readonly<S>` | 创建状态快照 |
| `$restore` | `(snapshot: Readonly<S>): void` | 从快照恢复 |
| `dispatch` | `<K>(name: K, ...args): InferActionReturn<A,K>` | 执行 action（类型安全重载 + 字符串重载） |
| `getter` | `<K>(name: K): InferGetterReturn<G,K>` | 获取 getter 值 |
| `getGetterNames` | `(): string[]` | getter 名称列表 |
| `subscribe` | `(listener: StateListener<S>): () => void` | 订阅状态变化，返回取消函数 |
| `startBatch` / `endBatch` | `(): void` | 手动批量更新边界 |
| `batch` | `<T>(fn: () => T): T` | 批量上下文执行，合并订阅通知 |
| `use` | `(plugin: Plugin): () => void` | 安装插件，返回卸载函数 |
| `destroy` | `(): void` | 销毁 Store |
| `getCached` | `<K>(key: K): S[K]` | 从缓存取状态值 |
| `enableCache` / `disableCache` | `(keys?: Array<keyof S>)` | 启用/禁用缓存 |
| `invalidateCache` | `<K>(key?: K): void` | 清除缓存（指定键或全部） |
| `getCacheStats` | `(): CacheStats` | 缓存统计（命中/未命中/淘汰） |
| `hooks` | `IHookSystem` | 实例级钩子系统 |
| `destroyed` | `boolean` | 是否已销毁 |

### 只读属性

- `store.name: string`
- `store.state: S`（受状态保护；只读语义）
- `store.actions: A`
- `store.hooks: IHookSystem`

### `isGeomStore(value): boolean`

判断一个值是否为 GeomStore 实例。

---

## 二、微信小程序集成

所有集成函数均为**高阶函数**：`(store, options) => (config) => enhancedConfig`，直接包住 `Page()/Component()/App()` 的配置对象。

### `ConnectOptions<S, A>`

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `mapState?` | `(keyof S)[] \| Record<string, string>` | 映射 state。数组简写（本地名=store名）；对象形式重命名（本地名→store名） |
| `mapGetters?` | `string[] \| Record<string, string>` | 映射 getters |
| `mapActions?` | `(keyof A)[] \| Record<string, keyof A>` | 映射 actions（数组或对象重命名） |
| `autoInject?` | `boolean` | 自动注入到 data/globalData（使用 `getCached`） |
| `injectMapping?` | `Record<string, string>` | 自动注入的字段映射（store 键 → 本地键） |
| `autoUpdateOnShow?` | `boolean` | onShow/attached 时更新注入（默认仅 onLoad） |

### `withPageStore(store, options?)(pageConfig)`

接入微信小程序 Page。自动在 `onLoad` 绑定映射、`onUnload` 清理订阅（实例级，支持同名页面栈多实例）。

```typescript
import { withPageStore } from '@openlide/geomstore/integrations'

Page(withPageStore(store, {
  mapState: ['count', 'name'],          // 或 { total: 'count' }
  mapActions: ['increment'],            // 或 { addOne: 'increment' }
  mapGetters: ['double'],
})({
  data: { localData: 1 },
  onLoad() {
    this.data.count      // 已映射
    this.increment()     // 已绑定
  },
}))
```

### `withComponentStore(store, options?)(componentConfig)`

接入微信小程序 Component。映射的 actions 自动合并进 `methods`；绑定发生在 `lifetimes.attached`，清理在 `detached`；`autoUpdateOnShow` 使用 `pageLifetimes.show`。

### `withAppStore(store, options?)(appConfig)` 与 `createApp(store, options?)(appConfig)`

两者等价。接入 App：状态同步到 `globalData`，actions 绑定到 App 实例，并在 `onLaunch` 暴露调试 API。

```typescript
import { withAppStore } from '@openlide/geomstore/integrations'

App(withAppStore(appStore, { mapState: ['userInfo'], mapActions: ['initApp'] })({
  onLaunch() { this.initApp() },
}))

// 任意位置访问：
const app = getApp()
app.getStore()        // Store 实例
app.getState()        // 状态
app.dispatch('xxx')   // 执行 action
app.subscribe(cb)     // 订阅
```

> 注意：App 级订阅贯穿小程序运行期，只在 onLaunch 建立，不在 onHide 清理。

### 类型辅助（`PageThis` / `ComponentThis`）

```typescript
import type { PageThis } from '@openlide/geomstore/integrations'

type HomePageThis = PageThis<StateType, ActionsType, ConnectOptionsType, ExtraMethods>
```

用于在页面方法中获取映射状态与方法（含精确参数类型）。

### 企业级方案（`@openlide/geomstore/integrations/enterprise`）

| API | 说明 |
| --- | --- |
| `createUserStore(config)` | 创建多账号隔离的用户 Store |
| `StoreManager` / `storeManager` | Store 管理器（单例） |
| `initHotUpdate(store, config)` / `restoreFromHotUpdate()` | 热更新备份与恢复 |
| `OfflineManager` / `initBackgroundSync(config)` / `unregisterBackgroundSync()` | 离线状态管理与前后台同步 |
| `createEnterpriseApp(store, options)` | 企业级 App 集成（组合用户 Store + 热更新 + 离线同步） |

---

## 三、插件系统

### 插件接口

```typescript
interface Plugin {
  name: string
  install: (store: Store) => void | (() => void)   // 返回可选卸载函数
}
```

安装：`const uninstall = store.use(plugin)`；卸载：`uninstall()`。

### 钩子（HookSystem）

每个 Store 拥有独立 `store.hooks`。钩子名 `HookName`：

- `beforeSetState` / `afterSetState` — 参数 `(key, value)`
- `beforePatch` / `afterPatch` — 参数 `(partialState)`
- `beforeDispatch` / `afterDispatch` — 参数 `(actionName, args, result?)`
- `beforeReplaceState` / `afterReplaceState` — 参数 `(newState)`
- `onError` — 参数 `(error, context?)`

```typescript
const off = store.hooks.on('afterDispatch', (name, args, result) => { ... })
off()  // 取消注册
store.hooks.emit('beforeDispatch', 'increment', [])
store.hooks.clear('beforeDispatch')   // 清空指定；无参清空全部
store.hooks.size('afterDispatch')     // 该钩子监听器数
store.hooks.listenerCount('afterDispatch') // 推荐：语义明确的监听器计数
```

### 内置插件

| 插件 | 用法 | 说明 |
| --- | --- | --- |
| `loggerPlugin` | `store.use(loggerPlugin)` | 开发日志（生产环境自动禁用） |
| `persistencePlugin` | `store.use(persistencePlugin)` 或 `store.use(persistencePlugin(options))` | 持久化（见下） |
| `devtoolsPlugin` | `store.use(devtoolsPlugin)` | 暴露 `globalThis.__GEOMSTORE_STORES__[name]` 与 `globalThis.__GEOMSTORE_DEVTOOLS__[name]`（生产环境禁用） |
| `builtinPlugins` | 数组 | `[loggerPlugin, persistencePlugin, devtoolsPlugin]` |

### `persistencePlugin(options?)`

| 选项 | 类型 | 说明 |
| --- | --- | --- |
| `key?` | `string \| ((storeName) => string)` | 存储键（默认 `geomstore_${name}`） |
| `storage?` | `StorageBackend` | 自定义后端（`getItem/setItem/removeItem`，可异步）。默认使用 `wx.getStorageSync` 等同步存储 |
| `filter?` | `(state) => Partial<S>` | 持久化前过滤字段 |
| `validate?` | `(state) => boolean` | 恢复前校验，false 拒绝恢复 |
| `restore?` | `boolean` | 是否启动时恢复（默认 true） |
| `debounce?` | `number` | 保存防抖毫秒 |
| `clearOnUninstall?` | `boolean` | 卸载时是否清除存储（默认 false） |

### 性能/分析插件（`@openlide/geomstore/plugins/performance`）

```typescript
import { analyzerPlugin, createAnalyzerPlugin } from '@openlide/geomstore/plugins/performance'

store.use(analyzerPlugin)
store.use(createAnalyzerPlugin({ sampleRate: 1.0, threshold: 16, trackMemory: true }))
// 访问：globalThis.__GEOMSTORE_ANALYZER__['store-name'].getStats() / .analyzeBottlenecks()
```

### 时间旅行插件（`@openlide/geomstore/plugins/devtools`）

```typescript
import { timeTravelPlugin } from '@openlide/geomstore/plugins/devtools'

store.use(timeTravelPlugin({ maxSize: 100, autoRecord: true }))
// store.__timeTravel__.undo() / .redo() / .goTo(index)
```

---

## 四、状态选择器（`@openlide/geomstore/selectors`）

| API | 签名 | 说明 |
| --- | --- | --- |
| `createSelector` | `(fn, options?) => Selector` | 带缓存的选择器（`options: { cache?, cacheSize?, cacheTTL?, equalityFn? }`） |
| `createMemoizedSelector` | `(fn, equalityFn?) => Selector` | 记忆化选择器（默认 `shallowEqual`） |
| `createParametricSelector` | `(fn) => (state) => (params) => R` | 参数化选择器，WeakMap 缓存避免内存泄漏 |
| `createStructuredSelector` | `({ key: selector, ... }) => Selector` | 结构化组合，返回对象 |
| `SelectorComposer` | 类 | 组合多个选择器 + combiner |
| `SelectorFactory` | 类 | 选择器工厂，管理缓存执行（`new SelectorFactory(fn, opts)`，`.execute(state)` 返回 `{ value, fromCache }`） |

```typescript
import { createSelector, createMemoizedSelector, createParametricSelector } from '@openlide/geomstore'

const selectCount = createSelector((s) => s.count)
const memo = createMemoizedSelector((s) => s.items.filter(i => i.active).length)
const byId = createParametricSelector((s, id) => s.items[id])
byId(state)(id)
```

---

## 五、Store 组合（`@openlide/geomstore/compose`）

### `composeStore(stores, options?)`

组合多个 Store 为一个根 Store（类实例，性能优化 + 防抖通知）。

```typescript
import { composeStore } from '@openlide/geomstore'

const root = composeStore([userStore, cartStore], {
  namespace: true,    // 命名空间模式：键格式 'storeName/key'
  strict: true,       // 访问不存在 store 时报错
  lazy: false,        // 延迟初始化
  tree: false,        // Store 树结构
})

// 命名空间模式下：
root.$patch({ 'userStore/name': 'Alice' })
root.getState() // { userStore: {...}, cartStore: {...} }
```

`ComposeOptions`：`{ namespace?: string | boolean, lazy?: boolean, strict?: boolean, tree?: boolean }`。`namespace` 为 true 时用默认分隔符 `/`，也可传字符串前缀。

### `createStoreTree(stores)`

创建树形结构 `StoreTreeNode`：`{ name, store, children? }`。

### `StoreRegistry` / `globalRegistry`

Store 注册表与全局注册表。用于按名称注册/查找 Store。

---

## 六、错误处理（`@openlide/geomstore/error`）

### 错误类

`GeomStoreError`（基类）及其子类：`ActionError`、`StateError`、`SelectorError`、`PluginError`、`ComposeError`、`ValidationError`。

枚举 `ErrorCode` 含 `E_ACTION_*`、`E_STATE_*` 等错误码。

判定函数：`isGeomStoreError`、`isActionError`、`isStateError`、`isSelectorError`、`isPluginError`、`isValidationError`。

创建：`createError(code, message, context?)`。

### `ErrorBoundary`

```typescript
import { ErrorBoundary, withErrorBoundary } from '@openlide/geomstore'

const boundary = new ErrorBoundary({ onError: (ctx) => report(ctx) })
// 或函数包装：withErrorBoundary(fn, options)
```

### `ErrorRecovery` / `RecoveryStrategy`

```typescript
import { ErrorRecovery, RecoveryStrategy } from '@openlide/geomstore'

const recovery = new ErrorRecovery()
recovery.configure('E_ACTION_FAILED', RecoveryStrategy.retry(3, 500))
recovery.configure('E_NETWORK', RecoveryStrategy.fallback(defaultValue))
```

策略：`RecoveryStrategy.retry(count, delay?)` / `.fallback(value)` 等。导出 `createDefaultErrorRecovery()`、`defaultErrorRecovery`。

### 错误监控

`ErrorMonitoring`（`{ onError, onWarning, onRecover }`）、`ErrorAggregator`、`ConsoleReporter`、`HttpReporter`、`createDefaultMonitoring()`、`getDefaultMonitoring()`、`defaultMonitoring`。

---

## 七、快照系统（`@openlide/geomstore/snapshot`）

| API | 说明 |
| --- | --- |
| `createSnapshot(state)` | 迭代式深克隆（循环引用检测） |
| `createSnapshotAsync(state, options?)` | 异步非阻塞快照，支持进度回调 |
| `SnapshotManager` | 快照管理器 |

```typescript
import { createSnapshot, createSnapshotAsync, SnapshotManager } from '@openlide/geomstore'

const snap = createSnapshot(store.state)
store.$restore(snap)

const asyncSnap = await createSnapshotAsync(store.state, {
  onProgress: (p) => console.log(p.percent),
})
```

---

## 八、性能监控（`@openlide/geomstore/performance`）

| API | 说明 |
| --- | --- |
| `PerformanceMonitor` | 性能监控（`start/end/mark/measure/getMetrics` 等） |
| `MetricsCollector` | 指标收集器 |
| `PerformanceAnalyzer` | 性能分析器 |

同时导出优化工具：`LRUCache`、`AsyncBatchNotifier`、`StateFingerprint`、`SubscriptionManager`、`iterativeDeepEqual`、`scheduleIdle`、`debounce`、`throttle`、`createLRUCache` 等。

---

## 九、LRU 缓存（`@openlide/geomstore/cache`）

```typescript
import { LRUCache } from '@openlide/geomstore'

const cache = new LRUCache({ capacity: 100, ttl: 60000, trackAccessTime: true, enableStats: true })
cache.set('k', v)
cache.get('k')
cache.getCacheStats() // { size, hits, misses, evictions, ... }
cache.clear()
```

`CacheOptions`：`{ capacity?, ttl?, trackAccessTime?, enableStats? }`；`LRUCacheStats` 含命中率统计。

---

## 十、Action 增强（`@openlide/geomstore/actions`）

### 执行器与加载器

| API | 说明 |
| --- | --- |
| `ActionExecutor` | 异步 action 执行器，返回 `ActionResult<T>`（`{ success, data, error, duration, ... }`） |
| `ActionLoader` / `withLoading` | 自动管理 loading/error 状态 |
| `ActionUtils` | Action 工具（支持依赖注入） |

### 装饰器

| 装饰器 | 说明 |
| --- | --- |
| `withLog(fn, label?)` | 日志 |
| `withDebounce(fn, delay)` | 防抖 |
| `withThrottle(fn, interval)` | 节流 |
| `withCache(fn, options?)` | 结果缓存（`{ key?, ttl? }`） |
| `withRetry(fn, options?)` | 重试（`{ retries?, delay?, backoff? }`） |
| `withTimeout(fn, timeout)` | 超时 |
| `createDecorator(config)` | 自定义装饰器工厂 |

```typescript
import { withRetry, withTimeout, withLoading } from '@openlide/geomstore'

const store = createStore({
  state: { loading: false },
  actions: {
    fetchUser: withRetry(async () => { ... }, { retries: 3 }),
    slowTask: withTimeout(() => { ... }, 3000),
  },
})
```

---

## 十一、工具函数

从根包导出：`isObject`、`isPlainObject`、`isFunction`、`isArray`、`isPromise`、`shallowEqual`、`deepEqual`、`deepMerge`、`get`、`set`、`noop`、`identity`、`uniqueId`、`clone`。

---

## 十二、常用类型

| 类型 | 说明 |
| --- | --- |
| `Store<S, A, G>` | Store 接口 |
| `StoreOptions<S, A, G>` | createStore 选项 |
| `State` | `Record<string, unknown>` |
| `Actions` | `Record<string, (...args) => any>` |
| `Getters<S>` | `Record<string, (state: S) => unknown>` |
| `StateListener<S>` | `(state: S) => void` |
| `ConnectOptions<S, A>` | 集成选项 |
| `PageThis` / `ComponentThis` | 页面/组件方法 this 类型 |
| `Plugin` / `HookName` / `IHookSystem` | 插件与钩子 |
| `PersistenceOptions` / `StorageBackend` | 持久化 |
| `Selector` / `SelectorOptions` | 选择器 |
| `ComposeOptions` / `StoreTreeNode` / `ComposedStore` | 组合 |
| `TimeTravelOptions` | 时间旅行配置 |
| `ActionResult<T>` / `AsyncActions` | Action 结果/异步 action |
